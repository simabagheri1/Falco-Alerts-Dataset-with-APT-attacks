# Falco-Alerts-Dataset-with-APT-attacks
A dataset of Falco alerts with simulation of eight APT attacks
