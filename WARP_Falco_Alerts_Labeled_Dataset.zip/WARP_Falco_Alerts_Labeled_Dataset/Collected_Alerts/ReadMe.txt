1- The Raw Alerts folder include the alerts we collected from eleven Pods inside Node xxxxx in our testbed while injecting eight attacks in the normal operation of the cluster.
2- The Final Processed and Labeled Alerts folder is a procesed representation of the Raw Alerts and they are Labeled.
   Attack labels is done through identifying attack alerts seperately.
3- Final Balanced Labeled Falco Alerts file is the balanced file. Since the number of normal alerts is always huge and number of attack alerts is
   usually less than 1 percent, we undersample the normal alerts and oversample the attack samples with techniques discussed in our paper

Reference: 
- Attack injection using CALDERA guide
- Warping the Defence Timeline: Non-disruptive Proactive Attack Mitigation for Kubernetes Clusters. Authors: Sima Bagheri. et al.

