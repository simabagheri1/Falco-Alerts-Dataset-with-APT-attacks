Formatting:
Cointainer ID : MITRE  ATT&CK Tactic

From the Collected Alerts in each Pod (including normal and attack alerts), the MITRE ATT&CK tactic tag is extracted